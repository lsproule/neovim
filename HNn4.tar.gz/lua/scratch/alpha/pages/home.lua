return {
  {
    { "Hello", "World" },
    { function() vim.notify("Deez") end, require("telescope.builtin").keymaps },
  },
  "OCTOPI",
  true,
}
